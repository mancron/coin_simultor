package DTO;

public class WatchlistDTO {

	public WatchlistDTO() {
	}

}
