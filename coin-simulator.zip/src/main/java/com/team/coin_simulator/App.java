package com.team.coin_simulator;
//개발하다가 "어? 이 화면에는 자산 정보랑 현재가가 같이 나와야 하는데?" 싶으면 **두 개를 합친 새로운 DTO(~ViewDTO)**를 그때그때 추가해서 만드세요.
//market_candle의 경우 데이터가 수백만 개가 쌓일 수 있으므로, DTO 리스트에 담을 때 **필요한 기간만 조회(WHERE 조건)**해서 담도록 주의해야 합니다.
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
